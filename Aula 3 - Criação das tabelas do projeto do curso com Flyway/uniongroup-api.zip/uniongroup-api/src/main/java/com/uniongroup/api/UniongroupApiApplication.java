package com.uniongroup.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniongroupApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(UniongroupApiApplication.class, args);
    }

}
